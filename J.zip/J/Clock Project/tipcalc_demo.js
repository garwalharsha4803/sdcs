var calculateTip1 = function() {
  let billAmount = document.getElementById("bill_amount").value;
  let serviceBill = document.getElementById("select_service").value;
  let billMember = document.getElementById("bill_mem").value;

  let calculation = (billAmount * serviceBill) / billMember;
  calculation = Math.round(calculation * 100) / 100;
  calculation = calculation.toFixed(2);

  let billAmountDisplay = (document.getElementById("totalTip").style.display =
    "block");

  tip.innerText = calculation;
};

let billnotdisplay = (document.getElementById("totalTip").style.display =
  "none");

let dispaly = calculateTip.addEventListener("click", calculateTip1);
